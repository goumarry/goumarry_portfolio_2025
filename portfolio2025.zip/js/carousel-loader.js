
document.addEventListener("DOMContentLoaded", function () {
  const loadCarousel = (containerId, projectFiles) => {
    const carouselContent = document.getElementById(containerId);
    projectFiles.forEach((file, index) => {
      fetch(file)
        .then(response => response.text())
        .then(html => {
          const tempDiv = document.createElement("div");
          tempDiv.innerHTML = html.trim();
          const carouselItem = tempDiv.firstChild;
          if (index === 0) {
            carouselItem.classList.add("active");
          }
          carouselContent.appendChild(carouselItem);
        });
    });
  };

  loadCarousel("carouselBUT1", ["projets/projet1.html", "projets/projet2.html", "projets/projet3.html"]);
  loadCarousel("carouselBUT2", ["projets/projet4.html", "projets/projet5.html", "projets/projet6.html"]);
});
